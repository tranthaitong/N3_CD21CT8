/*Verify you are able to change or reorder previously added product
        *  Test Data = QTY = 10
        Test Steps:
        1. Go to http://live.techpanda.org/
        2. Click on my account link
        3. Login in application using previously created credential
        4. Click on 'REORDER' link , change QTY & click Update
        5. Verify Grand Total is changed
        6. Complete Billing & Shipping Information
        7. Verify order is generated and note the order number

        Expected outcomes:
        1) Grand Total is Changed
        2) Order number is generated

 */
package test;

import driver.driverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;
@Test
public class TestCase8 {
    public static void testCase08() {
        WebDriver driver = new EdgeDriver();
        try {
            // Step 1: Go to https://cachep.vn/
            driver.get("https://cachep.vn/");
            // Step 2. Login in application using previously created credential
            WebElement logBtn = driver.findElement(By.cssSelector("div[class='grid__item large--two-thirds'] li:nth-child(1) a:nth-child(1)"));
            logBtn.click();
            WebElement emailLog = driver.findElement(By.cssSelector("#CustomerEmail"));
            emailLog.clear();
            emailLog.sendKeys("trantongkudo2003@gmail.com");
            WebElement passLog = driver.findElement(By.cssSelector("#CustomerPassword"));
            passLog.clear();
            passLog.sendKeys("1234567890");
            WebElement logLog = driver.findElement(By.cssSelector("input[value='Đăng nhập']"));
            logLog.click();
            // Step 3. Click on 'REORDER' link , change QTY & click Update
            WebElement reorder = driver.findElement(By.cssSelector(".hdc-cart.hd-cart"));
            reorder.click();
            WebElement reorder1 = driver.findElement(By.xpath("//a[contains(text(),'Xem giỏ hàng')]"));
            reorder1.click();
            WebElement inputre = driver.findElement(By.xpath("//td[@data-label='Số lượng']//input[@id='updates_']"));
            inputre.clear();
            inputre.sendKeys("10");
            WebElement update = driver.findElement(By.cssSelector("form[class='cart table-wrap medium--hide small--hide'] button[name='update']"));
            update.click();
            //Step 5. Verify Grand Total is changed
            WebElement verif = driver.findElement(By.cssSelector("form[class='cart table-wrap medium--hide small--hide'] span[class='h3 cart__subtotal']"));
            String ve= verif.getText();

            if(ve.equals("800,000đ")) {
                System.out.println("Bằng");
            }
            else {
                System.out.println("Không Bằng");
            }
            //Step 6. Complete Billing & Shipping Information
            //Step 7. Verify order is generated and note the order number
            WebElement verif1 = driver.findElement(By.cssSelector("form[class='cart table-wrap medium--hide small--hide'] span[class='h3 cart__subtotal']"));
            String ve1 = verif1.getText();
            System.out.println(ve1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        driver.quit();
    }
}
