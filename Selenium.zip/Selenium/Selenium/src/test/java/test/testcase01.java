package test;

import driver.driverFactory;
import org.openqa.selenium.*;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.io.File;
import java.time.Duration;

@Test
public class testcase01 {
    public static void testcase01() {
        //Init web-driver session
        WebDriver driver = new EdgeDriver();
        try {
            //Step 1. Go to https://cachep.vn/
            driver.get("https://cachep.vn/");
            //Step 2. Verify Title of the page
            String pageURL = driver.getCurrentUrl();
            String pageTitle = driver.getTitle();

            System.out.println(pageURL);
            System.out.println(pageTitle);
            //Step 3. Click on -> Sách Thiếu Nhi
            By leftClickPlace = By.cssSelector("div[class='grid__item pd-left0 large--eight-twelfths'] li:nth-child(1) a:nth-child(1)");
            WebElement leftClickPlaceElem = driver.findElement(leftClickPlace);
            leftClickPlaceElem.click();
            //Step 4. In the list of all mobile , select SORT BY -> dropdown as name
            WebElement dropdownElement = driver.findElement(By.cssSelector("#SortBy"));
            Select selectOption = new Select(dropdownElement);
            selectOption.selectByVisibleText("Theo bảng chữ cái từ A-Z");
            //Step 5. Verify all products are sorted by name
            TakesScreenshot screenshot =((TakesScreenshot)driver);
            File srcFile= screenshot.getScreenshotAs(OutputType.FILE);
            File destFile = new File(".\\src\\test\\java\\test\\testcase01.png");
            FileHandler.copy(srcFile, destFile);
            //debug purpose only
            Thread.sleep(2000);
        } catch (Exception e) {
            e.printStackTrace();
        }

        //7. Quit browser session
        driver.quit();
    }
}