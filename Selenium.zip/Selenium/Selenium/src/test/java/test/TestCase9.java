/*  Verify Discount Coupon works correctly

Test Case Description:
1. Go to http://live.techpanda.org/
2. Go to Mobile and add IPHONE to cart
3. Enter Coupon Code
4. Verify the discount generated

TestData:  Coupon Code: GURU50
Expected result:
1) Price is discounted by 5%
*/

package test;
import driver.driverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

@Test
public class TestCase9 {
    public static void TestCase9(){
        WebDriver driver = new EdgeDriver();
        try{
            // Step 1: Go to https://cachep.vn/
            driver.get("https://cachep.vn/");
            //2. Go to Sách Thiếu Nhi and add Bộ chơi mà học to cart
            WebElement butmobi = driver.findElement(By.xpath("//ul[@class='navbar-list no-bullets']//a[contains(text(),'Sách Thiếu Nhi')]"));
            butmobi.click();
            WebElement butcart = driver.findElement(By.xpath("/html[1]/body[1]/div[8]/main[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[5]/button[3]"));
            butcart.click();
//
            WebElement butcart1 = driver.findElement(By.cssSelector(".btnProceedCheckout"));
            butcart1.click();
//
            //3. Enter Coupon Code
            WebElement inputcode = driver.findElement(By.id("discount.code"));
            inputcode.clear();
            inputcode.sendKeys("HELLO");

            WebElement butapply = driver.findElement(By.cssSelector("button[class='field-input-btn btn btn-default'] i[class='btn-spinner icon icon-button-spinner']"));
            butapply.click();
            //4. Verify the discount generated
            WebElement verif = driver.findElement(By.xpath("//form[@class='cart table-wrap medium--hide small--hide']//span[@class='h3 cart__subtotal'][contains(text(),'44,000₫')]"));
            String ve= verif.getText();

            if(ve.equals("44,000đ")) {
                System.out.println("Không giảm giá");
            }
            else {
                System.out.println("Đã giảm giá");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        driver.quit();
    }
}

