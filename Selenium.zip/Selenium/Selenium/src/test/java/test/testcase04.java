package test;

import driver.driverFactory;
import org.openqa.selenium.*;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Test
public class testcase04 {
    public static void testcase04() {
//Init web-driver session
        WebDriver driver = new EdgeDriver();
        try {
//Step 1. Go to https://cachep.vn/
            driver.get("https://cachep.vn/");
            //Step 2. Click on -> Sách Thiếu Nhi
            WebElement mobileMenu = driver.findElement(By.cssSelector("div[class='grid__item pd-left0 large--eight-twelfths'] li:nth-child(1) a:nth-child(1)"));
            mobileMenu.click();
            Thread.sleep(2000);
            //Step 3. In mobile products list, click on "Add To Compare" for Sony Xperia and iPhone
            WebElement sonyAddToCompare = driver.findElement(By.xpath("//div[@class='grid-uniform product-list mg-left-0']//div[1]//div[1]//div[5]//button[3]"));
            sonyAddToCompare.click();
            Thread.sleep(2000);
            WebElement iphoneAddToCompare = driver.findElement(By.xpath("//a[@class='modalAddComplete-close']"));
            iphoneAddToCompare.click();
            Thread.sleep(5000);
            //Step 4. Click on "COMPARE" button
            WebElement compareButton = driver.findElement(By.xpath("//div[@class='collection-body']//div[2]//div[1]//div[5]//button[3]"));
            compareButton.click();
            Thread.sleep(5000);
            WebElement updateButton = driver.findElement(By.xpath("//button[@name='update']"));
            updateButton.click();
            Thread.sleep(2000);
            //Step 5. Verify the pop-up window and check that the products are reflected in it
            WebElement closeWindow = driver.findElement(By.xpath("//a[@class='btnProceedCheckout']"));
            closeWindow.click();
            Thread.sleep(2000);
            //Step . Verify cart is empty
                TakesScreenshot screenshot = ((TakesScreenshot) driver);
              File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
               File destFile = new File(".\\src\\test\\java\\test\\testcase04.png");
               FileHandler.copy(srcFile, destFile);
              Thread.sleep(2000);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //Close the driver after test execution
            driver.quit();
        }
    }
}